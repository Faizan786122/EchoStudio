package com.faizu.echostudio

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class MainActivity : Activity() {
    private val sampleRate = 44100
    private val permissionCode = 44
    private val createWavCode = 45
    private var audioThread: Thread? = null
    private val running = AtomicBoolean(false)
    private val recording = AtomicBoolean(false)
    private var delayMs = 280
    private var feedback = 38
    private var wetLevel = 55
    private var effectOn = true
    private var recordFile: File? = null
    private var recordBytes = 0L
    private lateinit var status: TextView
    private lateinit var liveButton: Button
    private lateinit var recordButton: Button
    private lateinit var stopButton: Button
    private lateinit var saveButton: Button
    private lateinit var delayValue: TextView
    private lateinit var feedbackValue: TextView
    private lateinit var levelValue: TextView
    private lateinit var effectButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 18)
            setBackgroundColor(0xFF101522.toInt())
        }
        val title = TextView(this).apply {
            text = "ECHO STUDIO"
            textSize = 25f
            setTextColor(0xFF17C7E8.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, lp(width = -1, height = 58))
        val subtitle = TextView(this).apply {
            text = "LIVE VOICE • DIGITAL DELAY"
            textSize = 12f
            setTextColor(0xFFB8C5D8.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, lp(-1, 28))
        status = label("Status: ready")
        root.addView(status, lp(-1, 44))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF1A2232.toInt())
        }
        delayValue = label("Delay: 280 ms")
        card.addView(delayValue, lp(-1, 32))
        card.addView(makeSlider(30, 900, delayMs) { v -> delayMs = v; delayValue.text = "Delay: $v ms" }, lp(-1, 48))
        feedbackValue = label("Feedback: 38%")
        card.addView(feedbackValue, lp(-1, 32))
        card.addView(makeSlider(0, 85, feedback) { v -> feedback = v; feedbackValue.text = "Feedback: $v%" }, lp(-1, 48))
        levelValue = label("Echo level: 55%")
        card.addView(levelValue, lp(-1, 32))
        card.addView(makeSlider(0, 100, wetLevel) { v -> wetLevel = v; levelValue.text = "Echo level: $v%" }, lp(-1, 48))
        effectButton = Button(this).apply {
            text = "EFFECT: ON"
            setOnClickListener {
                effectOn = !effectOn
                text = if (effectOn) "EFFECT: ON" else "EFFECT: OFF"
            }
        }
        card.addView(effectButton, lp(-1, 52))
        root.addView(card, lp(-1, -2))

        liveButton = Button(this).apply {
            text = "🎙 START LIVE ECHO"
            setOnClickListener { if (running.get()) stopAudio() else checkPermissionAndStart() }
        }
        root.addView(liveButton, lp(-1, 58))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        recordButton = Button(this).apply {
            text = "● RECORD"
            setOnClickListener { toggleRecording() }
        }
        stopButton = Button(this).apply {
            text = "■ STOP"
            setOnClickListener { stopAudio() }
        }
        row.addView(recordButton, LinearLayout.LayoutParams(0, 56, 1f))
        row.addView(stopButton, LinearLayout.LayoutParams(0, 56, 1f))
        root.addView(row, lp(-1, 60))
        saveButton = Button(this).apply {
            text = "⬇ SAVE RECORDING (WAV)"
            isEnabled = false
            setOnClickListener { saveRecording() }
        }
        root.addView(saveButton, lp(-1, 58))
        val note = TextView(this).apply {
            text = "Tip: Use earphones for better live echo. Speaker feedback may cause noise."
            textSize = 12f
            setTextColor(0xFF9BAAC0.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(note, lp(-1, 56))
        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(0xFFEAF2FF.toInt())
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun makeSlider(min: Int, max: Int, initial: Int, change: (Int) -> Unit): SeekBar {
        return SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    change(progress + min)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
    }

    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height).apply {
        topMargin = 5
        bottomMargin = 5
    }

    private fun checkPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), permissionCode)
        } else startAudio()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == permissionCode && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startAudio()
        else Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show()
    }

    private fun startAudio() {
        if (running.get()) return
        val minIn = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) {
            Toast.makeText(this, "Audio not supported on this device", Toast.LENGTH_LONG).show()
            return
        }
        val bufferSize = max(minIn, minOut) * 2
        val recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        val player = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        val frameBuffer = ShortArray(1024)
        val delayBuffer = ShortArray(sampleRate * 2)
        var writeIndex = 0
        running.set(true)
        liveButton.text = "■ STOP LIVE ECHO"
        status.text = "Status: live echo running"
        recorder.startRecording()
        player.play()
        audioThread = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            try {
                while (running.get()) {
                    val count = recorder.read(frameBuffer, 0, frameBuffer.size)
                    if (count <= 0) continue
                    val delaySamples = (delayMs * sampleRate / 1000).coerceIn(1, delayBuffer.size - 1)
                    val feedbackGain = feedback / 100.0
                    val wetGain = wetLevel / 100.0
                    val out = ShortArray(count)
                    for (i in 0 until count) {
                        val input = frameBuffer[i].toInt()
                        val readIndex = (writeIndex - delaySamples + delayBuffer.size) % delayBuffer.size
                        val delayed = delayBuffer[readIndex].toInt()
                        val echo = if (effectOn) delayed else 0
                        val mixed = (input + echo * wetGain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        out[i] = mixed.toShort()
                        val feedbackSample = if (effectOn) (input + delayed * feedbackGain).toInt() else input
                        delayBuffer[writeIndex] = feedbackSample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                        writeIndex = (writeIndex + 1) % delayBuffer.size
                    }
                    player.write(out, 0, count)
                    if (recording.get()) writePcm(out)
                }
            } catch (_: Exception) {
            } finally {
                try { recorder.stop() } catch (_: Exception) {}
                try { recorder.release() } catch (_: Exception) {}
                try { player.stop() } catch (_: Exception) {}
                try { player.release() } catch (_: Exception) {}
            }
        }
        audioThread?.start()
    }

    private fun toggleRecording() {
        if (!running.get()) {
            Toast.makeText(this, "Start live echo first", Toast.LENGTH_SHORT).show()
            return
        }
        if (!recording.get()) {
            recordFile = File(cacheDir, "echo_recording_${System.currentTimeMillis()}.pcm")
            recordBytes = 0
            recording.set(true)
            recordButton.text = "● RECORDING..."
            saveButton.isEnabled = false
            status.text = "Status: recording effected audio"
        } else {
            recording.set(false)
            recordButton.text = "● RECORD"
            status.text = "Status: recording stopped"
            saveButton.isEnabled = (recordFile?.length() ?: 0L) > 0
        }
    }

    @Synchronized private fun writePcm(samples: ShortArray) {
        val file = recordFile ?: return
        try {
            FileOutputStream(file, true).use { out ->
                val bytes = ByteArray(samples.size * 2)
                for (i in samples.indices) {
                    val v = samples[i].toInt()
                    bytes[i * 2] = (v and 0xff).toByte()
                    bytes[i * 2 + 1] = ((v shr 8) and 0xff).toByte()
                }
                out.write(bytes)
                recordBytes += bytes.size
            }
        } catch (_: Exception) {}
    }

    private fun stopAudio() {
        recording.set(false)
        running.set(false)
        audioThread?.join(500)
        audioThread = null
        liveButton.text = "🎙 START LIVE ECHO"
        recordButton.text = "● RECORD"
        status.text = "Status: stopped"
        saveButton.isEnabled = (recordFile?.length() ?: 0L) > 0
    }

    private fun saveRecording() {
        val pcm = recordFile
        if (pcm == null || !pcm.exists() || pcm.length() == 0L) {
            Toast.makeText(this, "Record something first", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, "EchoStudio_${System.currentTimeMillis()}.wav")
        }
        startActivityForResult(intent, createWavCode)
    }

    @Deprecated("Handled for Android document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createWavCode && resultCode == Activity.RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.use { output ->
                    writeWav(recordFile!!, output)
                }
                Toast.makeText(this, "WAV saved successfully", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Could not save: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun writeWav(pcmFile: File, output: OutputStream) {
        val dataSize = pcmFile.length().toInt()
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + dataSize)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1)
        header.putShort(1)
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)
        header.putShort(2)
        header.putShort(16)
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(dataSize)
        output.write(header.array())
        pcmFile.inputStream().use { input -> input.copyTo(output) }
        output.flush()
    }

    override fun onDestroy() {
        stopAudio()
        super.onDestroy()
    }
}
