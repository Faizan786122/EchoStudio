# Echo Studio Android app (starter project)

A native Android Kotlin starter for live microphone echo/delay and WAV recording.

## Build an APK

1. Install Android Studio on a computer.
2. Extract this project ZIP.
3. Open the `EchoStudio` folder in Android Studio.
4. Allow Gradle sync to finish (it may download Android Gradle Plugin / SDK components).
5. Connect your Android phone with USB debugging enabled, or use an emulator.
6. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show a link to the generated APK, usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Test

- Grant microphone permission.
- Tap **START LIVE ECHO**.
- Use earphones/headphones for best results. Phone speakers can create acoustic feedback.
- Tap **RECORD**, speak, then tap **RECORD** again to stop recording.
- Tap **STOP LIVE ECHO** if needed, then **SAVE RECORDING (WAV)** and choose a folder.

## Notes
- This is a starter implementation, not a polished release build.
- Live latency depends on the phone/audio route. Bluetooth devices may add substantial latency.
- Use wired Type-C earphones/headphones for better monitoring latency if supported.
- Audio processing currently uses mono 44.1 kHz PCM and a simple delay feedback loop.
